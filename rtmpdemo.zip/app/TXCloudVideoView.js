import {
    requireNativeComponent,
    View,

} from 'react-native';
import PropTypes from 'prop-types';
let iface = {
    name: 'TXCloudVideoView',
    propTypes: {
        url: PropTypes.string,
        ...View.propTypes // 包含默认的View的属性
    }
};

module.exports = requireNativeComponent('AndroidRCTWebView', iface);
