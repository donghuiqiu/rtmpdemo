// /*
// *设备管理
// * */
import React, {Component} from 'react';
import {
    View,
    Text,
    StyleSheet,
    Image,
    TouchableOpacity,
    NativeModules,
    NativeEventEmitter,
    DeviceEventEmitter, ScrollView,
} from 'react-native'
import TXCloudVedioView from './TXCloudVideoView';

export default class deviceManager extends Component{
    constructor(props,context) {
      super(props, context);

      };

    componentDidMount() {
    DeviceEventEmitter.addListener('startPlay', () => {
        console.warn("startPlay--》");

    });
    }


    render(){
        return(
            <View style={{flex:1,backgroundColor:"#fff"}}>
                <TXCloudVedioView
                    style={{width: '100%', height: 200}}
                    url={'rtmp://192.168.0.253:2022/live'}/>
            </View>
        )
    }



}
