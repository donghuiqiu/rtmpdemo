package com.rtmpdemo.view;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.events.RCTEventEmitter;
import com.facebook.react.views.image.ReactImageView;
import com.tencent.rtmp.ITXLivePlayListener;
import com.tencent.rtmp.TXLiveConstants;
import com.tencent.rtmp.TXLivePlayer;
import com.tencent.rtmp.TXLivePushConfig;
import com.tencent.rtmp.ui.TXCloudVideoView;

import android.Manifest;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;


import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.annotations.ReactProp;

import static com.tencent.rtmp.TXLiveConstants.PLAY_EVT_PLAY_BEGIN;
import static com.tencent.rtmp.TXLivePlayer.PLAY_TYPE_LIVE_RTMP;

/**
 * Created by dongfanggouwu-zy on 2018/4/2.
 */
public class ReactWebViewManager extends SimpleViewManager<TXCloudVideoView> {
    @Override
    public String getName() {
        return "AndroidRCTWebView";
    }
    TXLivePushConfig mLivePushConfig;
    TXLivePlayer mLivePlayer;
    @Override
    protected TXCloudVideoView createViewInstance(ThemedReactContext reactContext) {
        TXCloudVideoView webView = new TXCloudVideoView(reactContext);
        mLivePushConfig = new TXLivePushConfig();
        // 允许双指手势放大预览画面
        mLivePushConfig.setEnableZoom(true);
        // 设置噪声抑制
        mLivePushConfig.enableAEC(true);
        // 开启硬件加速
        mLivePushConfig.setHardwareAcceleration(TXLiveConstants.ENCODE_VIDEO_HARDWARE);
        // 开启 MainProfile 硬编码模式
        mLivePushConfig.enableVideoHardEncoderMainProfile(true);
        //创建player对象
        mLivePlayer = new TXLivePlayer(reactContext);
        //关键player对象与界面view
        mLivePlayer.setPlayerView(webView);
        mLivePlayer.enableHardwareDecode(true);

        mLivePlayer.setPlayListener(new ITXLivePlayListener() {
            @Override
            public void onPlayEvent(int i, Bundle bundle) {
                if(i==PLAY_EVT_PLAY_BEGIN)
                {
                    WritableMap map = Arguments.createMap();
                    map.putString("value","start");
                    sendEvent(reactContext, "startPlay",map);
                }
            }

            @Override
            public void onNetStatus(Bundle bundle) {

            }
        });
        return webView;
    }

    private void sendEvent(ReactContext reactContext,
                           String eventName,
                           @Nullable WritableMap params) {
        reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class).emit(eventName, params);
    }
    @ReactProp(name = "url")
    public void setUrl(TXCloudVideoView view, @Nullable String url) {
        Log.e("TAG", "setUrl");
        mLivePlayer.startPlay(url,PLAY_TYPE_LIVE_RTMP);
    }

    @ReactProp(name = "html")
    public void setHtml(WebView view, @Nullable String html) {
        Log.e("TAG", "setHtml");
        view.loadData(html, "text/html; charset=utf-8", "UTF-8");
    }
}
